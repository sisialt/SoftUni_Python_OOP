from project.computer_types.desktop_computer import DesktopComputer
from project.computer_types.laptop import Laptop


class ComputerStoreApp:
    VALID_TYPES = ["Desktop Computer", "Laptop"]

    def __init__(self):
        self.warehouse: list = []
        self.profits: int = 0

    def build_computer(self, type_computer: str, manufacturer: str, model: str, processor: str, ram: int):
        if type_computer not in ComputerStoreApp.VALID_TYPES:
            raise ValueError(f"{type_computer} is not a valid type computer!")

        if type_computer == "Laptop":
            new_comp = Laptop(manufacturer, model)
        else:
            new_comp = DesktopComputer(manufacturer, model)

        result = new_comp.configure_computer(processor, ram)

        self.warehouse.append(new_comp)

        return result

    def sell_computer(self, client_budget: int, wanted_processor: str, wanted_ram: int):
        for comp in self.warehouse:
            if comp.price > client_budget:
                continue

            if comp.processor != wanted_processor:
                continue

            if comp.ram < wanted_ram:
                continue

            self.profits += client_budget - comp.price
            self.warehouse.remove(comp)

            return f"{comp} sold for {client_budget}$."

        raise Exception("Sorry, we don't have a computer for you.")

# line 44: it was return, not raise Exception
