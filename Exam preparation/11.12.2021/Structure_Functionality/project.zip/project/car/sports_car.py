from project.car.car import Car


class SportsCar(Car):
    def set_range_speed_limit(self):
        return [400, 600]

