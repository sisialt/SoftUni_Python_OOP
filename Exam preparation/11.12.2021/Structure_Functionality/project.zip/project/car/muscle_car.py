from project.car.car import Car


class MuscleCar(Car):
    def set_range_speed_limit(self):
        return [250, 450]

